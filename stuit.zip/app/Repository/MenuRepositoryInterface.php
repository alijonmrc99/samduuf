<?php


namespace App\Repository;


interface MenuRepositoryInterface
{
    public function create($attributes);
}
