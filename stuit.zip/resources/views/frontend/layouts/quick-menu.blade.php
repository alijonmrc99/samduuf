<nav>
    <h4>{{__('data.quick-menu-title')}}</h4>
    <ul>
        <li><a href="#">{{__('data.quick-menu.faculties')}}</a></li>
        <li><a href="#">{{__('data.quick-menu.departments')}}</a></li>
        <li><a href="#">{{__('data.quick-menu.centres-and-departments')}}</a></li>
        <li><a href="#">{{__('data.quick-menu.entrant')}}</a></li>
        <li><a href="#">{{__('data.quick-menu.students')}}</a></li>
        <li><a href="#">{{__('data.quick-menu.scientific-activity')}}</a></li>
    </ul>
</nav>
