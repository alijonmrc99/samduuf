<section class="items interactive">
    <div class="container">
        <h3 class="title"><span>{{__('data.interactive-services')}}</span></h3>
        <div class="service row p-3">
            <div class="col">
                <div class="row">
                    <a href="#" class="col-md-6 col-12">{{__('data.interactive-service.adoption')}}</a>
                    <a href=" #" class="col-md-6 col-12">{{__('data.interactive-service.documents')}}</a>
                </div>
                <div class="row">
                    <a href="#" class="col-md-6 col-12">{{__('data.interactive-service.certificate')}}</a>
                    <a href=" #" class="col-md-6 col-12">{{__('data.interactive-service.online-bachelor')}}</a>
                </div>
                <div class="row">
                    <a href=" #" class="col-md-6 col-12">{{__('data.interactive-service.online-education')}}</a>
                    <a href=" #" class="col-md-6 col-12">{{__('data.interactive-service.online-master')}}</a>
                </div>
            </div>
        </div>
    </div>
</section>
